package com.aadventure.game;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.MotionEvent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.content.Context;
import android.os.SystemClock;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(new GameView(this));
    }

    private static class GameView extends View {
        private final Bitmap background;
        private final Bitmap character;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint hudPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Rect source = new Rect();
        private final RectF dest = new RectF();
        private final RectF characterDest = new RectF();

        // Camera stays fixed. Only the character position changes.
        private float characterX = 0f;
        private float characterY = 0f;
        private float inputX = 0f;
        private float inputY = 0f;
        private float knobX = 0f;
        private float knobY = 0f;
        private boolean touchingJoystick = false;
        private long lastFrame;
        private float joyCx, joyCy, joyRadius, knobRadius;

        GameView(Context context) {
            super(context);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            background = BitmapFactory.decodeResource(getResources(), R.drawable.game_background_fixed);
            character = BitmapFactory.decodeResource(getResources(), R.drawable.character_sprite);
            lastFrame = SystemClock.uptimeMillis();
            hudPaint.setTypeface(android.graphics.Typeface.create("sans", android.graphics.Typeface.BOLD));
            postInvalidateOnAnimation();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            long now = SystemClock.uptimeMillis();
            float dt = Math.min(0.04f, (now - lastFrame) / 1000f);
            lastFrame = now;

            updateCharacter(dt);
            drawFixedWorld(canvas);
            drawCharacter(canvas);
            drawJoystick(canvas);
            postInvalidateOnAnimation();
        }

        private void updateCharacter(float dt) {
            float speed = Math.min(getWidth(), getHeight()) * 0.52f;
            characterX += inputX * speed * dt;
            characterY += inputY * speed * dt;

            float maxX = getWidth() * 0.34f;
            float minY = -getHeight() * 0.10f;
            float maxY = getHeight() * 0.08f;
            characterX = clamp(characterX, -maxX, maxX);
            characterY = clamp(characterY, minY, maxY);
        }

        private void drawFixedWorld(Canvas canvas) {
            int w = getWidth();
            int h = getHeight();
            int iw = background.getWidth();
            int ih = background.getHeight();
            float screenAspect = w / Math.max(1f, (float) h);
            float imageAspect = iw / (float) ih;
            if (imageAspect > screenAspect) {
                float viewW = ih * screenAspect;
                float left = (iw - viewW) * 0.5f;
                source.set(Math.round(left), 0, Math.round(left + viewW), ih);
            } else {
                float viewH = iw / screenAspect;
                float top = (ih - viewH) * 0.5f;
                source.set(0, Math.round(top), iw, Math.round(top + viewH));
            }
            dest.set(0, 0, w, h);
            canvas.drawBitmap(background, source, dest, paint);
        }

        private void drawCharacter(Canvas canvas) {
            float h = getHeight();
            float charH = Math.min(h * 0.62f, 520f);
            float charW = charH * (character.getWidth() / (float) character.getHeight());
            float cx = getWidth() * 0.50f + characterX;
            float bottom = h * 0.98f + characterY;
            characterDest.set(cx - charW / 2f, bottom - charH, cx + charW / 2f, bottom);
            canvas.drawBitmap(character, null, characterDest, paint);
        }

        private void drawJoystick(Canvas canvas) {
            float w = getWidth();
            float h = getHeight();
            joyRadius = Math.max(55f, Math.min(w, h) * 0.115f);
            joyCx = joyRadius * 1.35f;
            joyCy = h - joyRadius * 1.25f;
            knobRadius = joyRadius * 0.40f;

            hudPaint.setStyle(Paint.Style.FILL);
            hudPaint.setColor(0x8A071B2C);
            canvas.drawCircle(joyCx, joyCy, joyRadius, hudPaint);
            hudPaint.setStyle(Paint.Style.STROKE);
            hudPaint.setStrokeWidth(Math.max(3f, joyRadius * 0.045f));
            hudPaint.setColor(0xCC35B9FF);
            canvas.drawCircle(joyCx, joyCy, joyRadius, hudPaint);

            hudPaint.setStyle(Paint.Style.FILL);
            hudPaint.setColor(0xD9E9F7FF);
            float a = joyRadius * 0.67f;
            drawTriangle(canvas, joyCx, joyCy - a, 0);
            drawTriangle(canvas, joyCx, joyCy + a, 180);
            drawTriangle(canvas, joyCx - a, joyCy, 270);
            drawTriangle(canvas, joyCx + a, joyCy, 90);

            float kx = joyCx + knobX;
            float ky = joyCy + knobY;
            hudPaint.setColor(0xD49BC8DE);
            canvas.drawCircle(kx, ky, knobRadius, hudPaint);
            hudPaint.setStyle(Paint.Style.STROKE);
            hudPaint.setStrokeWidth(2f);
            hudPaint.setColor(0xBFEAF8FF);
            canvas.drawCircle(kx, ky, knobRadius, hudPaint);
            hudPaint.setStyle(Paint.Style.FILL);
        }

        private void drawTriangle(Canvas canvas, float x, float y, float rotation) {
            android.graphics.Path path = new android.graphics.Path();
            float s = Math.max(8f, joyRadius * 0.12f);
            path.moveTo(0, -s);
            path.lineTo(s, s);
            path.lineTo(-s, s);
            path.close();
            canvas.save();
            canvas.rotate(rotation, x, y);
            canvas.translate(x, y);
            canvas.drawPath(path, hudPaint);
            canvas.restore();
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            float dx = event.getX() - joyCx;
            float dy = event.getY() - joyCy;
            float max = Math.max(1f, joyRadius - knobRadius);
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    if (Math.hypot(dx, dy) <= joyRadius * 1.35f) {
                        touchingJoystick = true;
                        updateJoystick(dx, dy, max);
                        return true;
                    }
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (touchingJoystick) {
                        updateJoystick(dx, dy, max);
                        return true;
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    touchingJoystick = false;
                    inputX = 0f;
                    inputY = 0f;
                    knobX = 0f;
                    knobY = 0f;
                    return true;
                default:
                    return true;
            }
        }

        private void updateJoystick(float dx, float dy, float max) {
            float distance = (float) Math.hypot(dx, dy);
            if (distance > max) {
                float scale = max / distance;
                dx *= scale;
                dy *= scale;
            }
            knobX = dx;
            knobY = dy;
            inputX = dx / max;
            inputY = dy / max;
        }

        private static float clamp(float value, float min, float max) {
            return Math.max(min, Math.min(max, value));
        }
    }
}
