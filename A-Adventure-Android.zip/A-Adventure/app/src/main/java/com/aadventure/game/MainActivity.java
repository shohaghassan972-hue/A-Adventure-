package com.aadventure.game;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );

        setContentView(new MeadowView());
    }

    private class MeadowView extends View {
        private final Bitmap meadow;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Rect src = new Rect();

        MeadowView() {
            super(MainActivity.this);
            meadow = BitmapFactory.decodeResource(getResources(), R.drawable.meadow);
            setBackgroundColor(Color.BLACK);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            int viewW = getWidth();
            int viewH = getHeight();
            int imageW = meadow.getWidth();
            int imageH = meadow.getHeight();

            // Scale to fill the screen while keeping the meadow's aspect ratio.
            float scale = Math.max((float) viewW / imageW, (float) viewH / imageH);
            int drawW = Math.round(imageW * scale);
            int drawH = Math.round(imageH * scale);
            int left = (viewW - drawW) / 2;
            int top = (viewH - drawH) / 2;

            src.set(0, 0, imageW, imageH);
            canvas.drawBitmap(meadow, src,
                new Rect(left, top, left + drawW, top + drawH), paint);
        }
    }
}
