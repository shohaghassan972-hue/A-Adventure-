package com.aadventure.game;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );

        setContentView(new GameView());
    }

    private class GameView extends View {
        private final Bitmap scene;
        private final Paint paint =
            new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Rect source = new Rect();

        GameView() {
            super(MainActivity.this);
            scene = BitmapFactory.decodeResource(
                getResources(), R.drawable.game_scene
            );
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            int w = getWidth();
            int h = getHeight();
            int iw = scene.getWidth();
            int ih = scene.getHeight();

            float scale = Math.max((float) w / iw, (float) h / ih);
            int dw = Math.round(iw * scale);
            int dh = Math.round(ih * scale);
            int left = (w - dw) / 2;
            int top = (h - dh) / 2;

            source.set(0, 0, iw, ih);
            canvas.drawBitmap(
                scene,
                source,
                new Rect(left, top, left + dw, top + dh),
                paint
            );
        }
    }
}
