package com.aadventure.game;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.MotionEvent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.ColorDrawable;
import android.content.Context;
import android.os.SystemClock;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        setContentView(new GameView(this));
    }

    private static class GameView extends View {
        private final Bitmap scene;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint hudPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Rect source = new Rect();
        private final RectF dest = new RectF();

        // Virtual camera position. The joystick moves this camera smoothly over the field.
        private float cameraX = 0f;
        private float cameraY = 0f;
        private float inputX = 0f;
        private float inputY = 0f;
        private float knobX = 0f;
        private float knobY = 0f;
        private boolean touchingJoystick = false;
        private long lastFrame;

        private float joyCx, joyCy, joyRadius, knobRadius;

        GameView(Context context) {
            super(context);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            scene = BitmapFactory.decodeResource(getResources(), R.drawable.game_scene);
            lastFrame = SystemClock.uptimeMillis();
            hudPaint.setTypeface(android.graphics.Typeface.create("sans", android.graphics.Typeface.BOLD));
            postInvalidateOnAnimation();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            long now = SystemClock.uptimeMillis();
            float dt = Math.min(0.04f, (now - lastFrame) / 1000f);
            lastFrame = now;

            updateCamera(dt);
            drawWorld(canvas);
            drawJoystick(canvas);

            postInvalidateOnAnimation();
        }

        private void updateCamera(float dt) {
            // Larger values mean faster exploration while keeping movement smooth.
            float speed = 230f;
            cameraX += inputX * speed * dt;
            cameraY += inputY * speed * dt;

            // Keep the camera inside the available image.
            float maxX = Math.max(0f, scene.getWidth() - getWidth());
            float maxY = Math.max(0f, scene.getHeight() - getHeight());
            cameraX = clamp(cameraX, 0f, maxX);
            cameraY = clamp(cameraY, 0f, maxY);
        }

        private void drawWorld(Canvas canvas) {
            int w = getWidth();
            int h = getHeight();
            int iw = scene.getWidth();
            int ih = scene.getHeight();

            // Use a viewport with the same aspect ratio as the screen. The joystick controls
            // the viewport position, so moving in each direction reveals a different part
            // of the meadow image instead of simply moving the HUD.
            float viewW = Math.min(iw, iw * ((float) w / Math.max(1f, h)) / (16f / 9f));
            viewW = Math.max(1f, Math.min(iw, viewW));
            float viewH = Math.min(ih, viewW * h / Math.max(1f, w));
            if (viewH > ih) {
                viewH = ih;
                viewW = viewH * w / Math.max(1f, h);
            }

            float maxX = Math.max(0f, iw - viewW);
            float maxY = Math.max(0f, ih - viewH);
            float sx = clamp(cameraX / Math.max(1f, iw - getWidth()), 0f, 1f) * maxX;
            float sy = clamp(cameraY / Math.max(1f, ih - getHeight()), 0f, 1f) * maxY;

            source.set(
                Math.round(sx),
                Math.round(sy),
                Math.round(sx + viewW),
                Math.round(sy + viewH)
            );
            dest.set(0, 0, w, h);
            canvas.drawBitmap(scene, source, dest, paint);
        }

        private void drawJoystick(Canvas canvas) {
            float w = getWidth();
            float h = getHeight();
            joyRadius = Math.max(55f, Math.min(w, h) * 0.115f);
            joyCx = joyRadius * 1.35f;
            joyCy = h - joyRadius * 1.25f;
            knobRadius = joyRadius * 0.40f;

            hudPaint.setStyle(Paint.Style.FILL);
            hudPaint.setColor(0x8A071B2C);
            canvas.drawCircle(joyCx, joyCy, joyRadius, hudPaint);
            hudPaint.setStyle(Paint.Style.STROKE);
            hudPaint.setStrokeWidth(Math.max(3f, joyRadius * 0.045f));
            hudPaint.setColor(0xCC35B9FF);
            canvas.drawCircle(joyCx, joyCy, joyRadius, hudPaint);

            // Direction arrows.
            hudPaint.setStyle(Paint.Style.FILL);
            hudPaint.setColor(0xD9E9F7FF);
            float a = joyRadius * 0.67f;
            drawTriangle(canvas, joyCx, joyCy - a, 0);
            drawTriangle(canvas, joyCx, joyCy + a, 180);
            drawTriangle(canvas, joyCx - a, joyCy, 270);
            drawTriangle(canvas, joyCx + a, joyCy, 90);

            float kx = joyCx + knobX;
            float ky = joyCy + knobY;
            hudPaint.setColor(0xD49BC8DE);
            canvas.drawCircle(kx, ky, knobRadius, hudPaint);
            hudPaint.setStyle(Paint.Style.STROKE);
            hudPaint.setStrokeWidth(2f);
            hudPaint.setColor(0xBFEAF8FF);
            canvas.drawCircle(kx, ky, knobRadius, hudPaint);
            hudPaint.setStyle(Paint.Style.FILL);
        }

        private void drawTriangle(Canvas canvas, float x, float y, float rotation) {
            android.graphics.Path path = new android.graphics.Path();
            float s = Math.max(8f, joyRadius * 0.12f);
            path.moveTo(0, -s);
            path.lineTo(s, s);
            path.lineTo(-s, s);
            path.close();
            canvas.save();
            canvas.rotate(rotation, x, y);
            canvas.translate(x, y);
            canvas.drawPath(path, hudPaint);
            canvas.restore();
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            float dx = event.getX() - joyCx;
            float dy = event.getY() - joyCy;
            float max = Math.max(1f, joyRadius - knobRadius);

            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    if (Math.hypot(dx, dy) <= joyRadius * 1.35f) {
                        touchingJoystick = true;
                        updateJoystick(dx, dy, max);
                        return true;
                    }
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (touchingJoystick) {
                        updateJoystick(dx, dy, max);
                        return true;
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    touchingJoystick = false;
                    inputX = 0f;
                    inputY = 0f;
                    knobX = 0f;
                    knobY = 0f;
                    return true;
                default:
                    return true;
            }
        }

        private void updateJoystick(float dx, float dy, float max) {
            float distance = (float) Math.hypot(dx, dy);
            if (distance > max) {
                float scale = max / distance;
                dx *= scale;
                dy *= scale;
            }
            knobX = dx;
            knobY = dy;
            inputX = dx / max;
            inputY = dy / max;
        }

        private static float clamp(float value, float min, float max) {
            return Math.max(min, Math.min(max, value));
        }
    }
}
