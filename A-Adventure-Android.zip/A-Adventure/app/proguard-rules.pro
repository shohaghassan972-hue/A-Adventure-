# A Adventure - no custom ProGuard rules
