# A Adventure v1.2

এই version-এ Movement Joystick যোগ করা হয়েছে।

- Application ID: com.aadventure.game
- Version Name: 1.2
- Version Code: 3
- Joystick: সামনে/পেছনে/বামে/ডানে টেনে camera/scene movement
- GitHub Actions debug APK এবং signed release APK দুটোই তৈরি করে
- Release signing-এর জন্য আগের একই key ব্যবহার করতে হবে

প্রথমে debug APK দিয়ে বর্তমান debug v1.1-এর ওপর update পরীক্ষা করা যাবে। Stable release-এর ক্ষেত্রে একই release key ব্যবহার করা বাধ্যতামূলক।
