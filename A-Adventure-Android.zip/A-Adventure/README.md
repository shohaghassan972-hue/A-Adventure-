# A Adventure

The app opens directly to the latest third-person game scene.

The existing GitHub Actions workflow is kept as the build workflow.
Future update support requires keeping the same applicationId and signing
future release builds with the same Android signing key.
