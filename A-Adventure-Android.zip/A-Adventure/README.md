# A Adventure

ছোট্ট সবুজ মাঠকে প্রথম playable screen হিসেবে দেখানো একটি Android game starter project।

## GitHub Actions দিয়ে APK বানানো
1. এই project GitHub repository-তে upload করুন।
2. `main` branch-এ push করুন।
3. **Actions → Build A Adventure APK → Run workflow** চাপুন।
4. Workflow শেষ হলে `A-Adventure-debug-APK` artifact থেকে APK নিন।

অ্যাপ চালু হলে landscape mode-এ সবুজ মাঠের scene সরাসরি দেখাবে।
