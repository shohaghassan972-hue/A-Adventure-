# A Adventure v1.2.3

এই version-এ Character Follow Camera যোগ করা হয়েছে।

- Application ID: com.aadventure.game
- Version Name: 1.2.3
- Version Code: 6
- Movement Joystick: সামনে/পেছনে/বামে/ডানে
- Camera: Character-এর পেছনে locked/follow করবে; Character-এর world movement অনুযায়ী camera/scene সঙ্গে যাবে
- Character: Camera frame-এর কেন্দ্রের কাছে থাকবে এবং হাঁটার সময় হালকা movement/bob থাকবে
- GitHub Actions debug APK এবং signed release APK দুটোই তৈরি করে
- Release signing-এর জন্য আগের একই key ব্যবহার করতে হবে
